package com.automacao.automacaoweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutomacaoWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(AutomacaoWebApplication.class, args);
    }

}